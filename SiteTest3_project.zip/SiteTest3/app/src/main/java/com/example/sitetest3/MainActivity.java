package com.example.sitetest3;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Toast;
import android.webkit.ValueCallback;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends Activity {
    private WebView webView;
    private TextView status;
    private boolean demoMode = false;
    private String answerKey = "{}";
    private String currentUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        answerKey = readAsset("answers.json");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("SITETEST 3.0");
        title.setTextSize(21);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        title.setPadding(8, 12, 8, 12);
        root.addView(title);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        addButton(buttons, "Учебный пример", v -> openDemo());
        addButton(buttons, "ClassTime", v -> openWebsite("https://www.classtime.com/"));
        addButton(buttons, "НаУрок", v -> openWebsite("https://naurok.com.ua/"));

        root.addView(buttons);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        addButton(tools, "Подсветить ключ", v -> highlightDemo());
        addButton(tools, "Текст страницы", v -> readDemoText());
        addButton(tools, "Журнал", v -> showLog());
        root.addView(tools);

        status = new TextView(this);
        status.setText("Открой учебный пример или сайт");
        status.setTextColor(Color.DKGRAY);
        status.setPadding(10, 6, 10, 6);
        root.addView(status);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                currentUrl = url;
                logEvent("PAGE_LOADED", url);
                if (demoMode && url.startsWith("file:///android_asset/")) {
                    status.setText("Учебная страница открыта");
                } else {
                    status.setText("Открыт сайт. Анализ и подсветка отключены.");
                }
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ));

        setContentView(root);
        logEvent("APP_STARTED", "SiteTest 3.0");
        openDemo();
    }

    private void addButton(LinearLayout parent, String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        parent.addView(b, new LinearLayout.LayoutParams(0, 52, 1f));
    }

    private void openDemo() {
        demoMode = true;
        logEvent("OPEN_DEMO", "Local practice page");
        webView.loadUrl("file:///android_asset/demo.html");
    }

    private void openWebsite(String url) {
        demoMode = false;
        currentUrl = url;
        logEvent("OPEN_WEBSITE", url);
        webView.loadUrl(url);
        status.setText("Открыт сайт. Подсветка и анализ ответов отключены.");
    }

    private void highlightDemo() {
        if (!demoMode || !currentUrl.startsWith("file:///android_asset/")) {
            Toast.makeText(this, "Подсветка доступна только в учебном примере", Toast.LENGTH_SHORT).show();
            return;
        }
        String safeJson = JSONObject.quote(answerKey);
        String script = "(function(){"
            + "const key=JSON.parse(" + safeJson + ");"
            + "document.querySelectorAll('[data-question]').forEach(q=>{"
            + "const id=q.getAttribute('data-question');"
            + "const correct=key[id];"
            + "q.querySelectorAll('[data-option]').forEach(o=>{"
            + "o.classList.remove('correct-answer');"
            + "if(correct && o.getAttribute('data-option')===correct) o.classList.add('correct-answer');"
            + "});"
            + "}); return 'Подсветка применена к учебному примеру';"
            + "})()";
        webView.evaluateJavascript(script, value -> {
            status.setText("Подсветка ответов учебного примера применена");
            logEvent("DEMO_HIGHLIGHT", "Teacher-provided local answer key");
        });
    }

    private void readDemoText() {
        if (!demoMode || !currentUrl.startsWith("file:///android_asset/")) {
            Toast.makeText(this, "Чтение текста доступно только в учебном примере", Toast.LENGTH_SHORT).show();
            return;
        }
        String script = "document.body.innerText";
        webView.evaluateJavascript(script, value -> {
            String clean = value == null ? "" : value;
            logEvent("DEMO_TEXT_READ", clean.length() + " characters");
            status.setText("Текст учебной страницы прочитан (" + clean.length() + " символов).");
            Toast.makeText(this, "Текст записан в журнал как количество символов", Toast.LENGTH_SHORT).show();
        });
    }

    private void showLog() {
        String data = readAssetOrFileLog();
        new android.app.AlertDialog.Builder(this)
            .setTitle("Журнал SiteTest")
            .setMessage(data)
            .setPositiveButton("Закрыть", null)
            .show();
    }

    private String readAssetOrFileLog() {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "activity.log");
            if (!f.exists()) return "Журнал пока пуст.";
            BufferedReader r = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(f)));
            StringBuilder s = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) s.append(line).append("\n");
            r.close();
            return s.toString();
        } catch (Exception e) {
            return "Не удалось прочитать журнал: " + e.getMessage();
        }
    }

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder s = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) s.append(line);
            r.close();
            return s.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    private void logEvent(String event, String details) {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "activity.log");
            java.io.FileWriter w = new java.io.FileWriter(f, true);
            String safe = details == null ? "" : details.replace("\n", " ").replace("\r", " ");
            w.write(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                + " | " + event + " | " + safe + "\n");
            w.close();
        } catch (IOException ignored) { }
    }

    @Override
    protected void onPause() {
        super.onPause();
        logEvent("APP_PAUSED", "Application paused or backgrounded");
    }

    @Override
    protected void onResume() {
        super.onResume();
        logEvent("APP_RESUMED", "Application resumed");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        logEvent("APP_CLOSED", "Activity destroyed");
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
