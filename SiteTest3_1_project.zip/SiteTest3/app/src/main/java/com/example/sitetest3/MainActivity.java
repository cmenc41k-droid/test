package com.example.sitetest3;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextView status;
    private boolean localDemo = false;
    private String currentUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("SITETEST 3.1");
        title.setTextSize(21);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        title.setPadding(8, 10, 8, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Диагностика учебных страниц");
        subtitle.setTextSize(13);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(4, 0, 4, 8);
        root.addView(subtitle);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addButton(row1, "Учебный пример", v -> openLocal("demo.html"));
        addButton(row1, "ClassTime — демо", v -> openLocal("classtime_demo.html"));
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        addButton(row2, "НаУрок — демо", v -> openLocal("naurok_demo.html"));
        addButton(row2, "ClassTime — сайт", v -> openWebsite("https://www.classtime.com/"));
        root.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        addButton(row3, "НаУрок — сайт", v -> openWebsite("https://naurok.com.ua/"));
        addButton(row3, "Проверить демо", v -> inspectLocalDemo());
        addButton(row3, "Журнал", v -> showLog());
        root.addView(row3);

        status = new TextView(this);
        status.setText("Открой один из учебных примеров");
        status.setTextColor(Color.DKGRAY);
        status.setTextSize(12);
        status.setPadding(10, 7, 10, 7);
        root.addView(status);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                currentUrl = url;
                localDemo = url.startsWith("file:///android_asset/");
                logEvent("PAGE_LOADED", url);
                if (localDemo) {
                    status.setText("Демо-страница загружена. Нажми «Проверить демо».");
                } else {
                    status.setText("Обычный просмотр сайта. Диагностика отключена.");
                }
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ));

        setContentView(root);
        logEvent("APP_STARTED", "SiteTest 3.1");
        openLocal("demo.html");
    }

    private void addButton(LinearLayout parent, String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        parent.addView(b, new LinearLayout.LayoutParams(0, 50, 1f));
    }

    private void openLocal(String asset) {
        localDemo = true;
        String url = "file:///android_asset/" + asset;
        logEvent("OPEN_LOCAL_DEMO", asset);
        webView.loadUrl(url);
    }

    private void openWebsite(String url) {
        localDemo = false;
        logEvent("OPEN_WEBSITE", url);
        webView.loadUrl(url);
        status.setText("Обычный просмотр сайта. Анализ страницы не выполняется.");
    }

    // Диагностика работает только с локальными демонстрационными HTML-файлами.
    private void inspectLocalDemo() {
        if (!localDemo || !currentUrl.startsWith("file:///android_asset/")) {
            Toast.makeText(this, "Проверка доступна только в локальном демо", Toast.LENGTH_SHORT).show();
            return;
        }
        String script = "(function(){"
            + "const qs=document.querySelectorAll('[data-question]');"
            + "let optionCount=0;"
            + "qs.forEach(q=>{"
            + "q.style.outline='2px solid #2878c8';"
            + "q.style.outlineOffset='3px';"
            + "q.querySelectorAll('[data-option]').forEach(o=>{"
            + "optionCount++; o.style.outline='1px dashed #777'; o.style.outlineOffset='1px';"
            + "});"
            + "});"
            + "return {questions:qs.length,options:optionCount};"
            + "})()";
        webView.evaluateJavascript(script, value -> {
            String result = value == null ? "нет данных" : value;
            status.setText("Демо-проверка: " + result);
            logEvent("DEMO_DIAGNOSTICS", result);
        });
    }

    private void showLog() {
        String data = readLog();
        new android.app.AlertDialog.Builder(this)
            .setTitle("Журнал SiteTest")
            .setMessage(data)
            .setPositiveButton("Закрыть", null)
            .show();
    }

    private String readLog() {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "activity.log");
            if (!f.exists()) return "Журнал пока пуст.";
            BufferedReader r = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(f)));
            StringBuilder s = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) s.append(line).append("\n");
            r.close();
            return s.toString();
        } catch (Exception e) {
            return "Ошибка чтения журнала: " + e.getMessage();
        }
    }

    private void logEvent(String event, String details) {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "activity.log");
            java.io.FileWriter w = new java.io.FileWriter(f, true);
            String safe = details == null ? "" : details.replace("\n", " ").replace("\r", " ");
            String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            w.write(time + " | " + event + " | " + safe + "\n");
            w.close();
        } catch (IOException ignored) { }
    }

    @Override
    protected void onPause() {
        super.onPause();
        logEvent("APP_PAUSED", "Application paused");
    }

    @Override
    protected void onResume() {
        super.onResume();
        logEvent("APP_RESUMED", "Application resumed");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        logEvent("APP_CLOSED", "Activity destroyed");
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
